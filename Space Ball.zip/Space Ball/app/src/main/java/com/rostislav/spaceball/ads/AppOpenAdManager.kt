package com.rostislav.spaceball.ads

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.rostislav.spaceball.R
import com.rostislav.spaceball.util.log
import java.util.Date

/**
 * App Open Ad — показується, коли користувач повертається у гру
 * (застосунок виходить на передній план), за рекомендованою схемою Google:
 *  - реклама кешується наперед і "живе" не довше 4 годин;
 *  - не показується поверх іншої повноекранної реклами;
 *  - не показується при холодному старті (перший onStart лише вантажить рекламу).
 */
class AppOpenAdManager(
    private val application: Application,
) : Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    companion object {
        /** Термін життя закешованої App Open реклами (години). */
        private const val AD_EXPIRY_HOURS = 4L
    }

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    private var loadTime = 0L

    private var currentActivity: Activity? = null

    /** Перший вихід на передній план (холодний старт) — рекламу не показуємо, лише вантажимо. */
    private var isColdStart = true

    fun register() {
        application.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        MobileAdsInitializer.onReady { loadAd() }
    }

    // -------------------------------------------------------------------------------------------
    // ProcessLifecycleOwner — застосунок вийшов на передній план
    // -------------------------------------------------------------------------------------------

    override fun onStart(owner: LifecycleOwner) {
        if (isColdStart) {
            isColdStart = false
            return
        }
        currentActivity?.let { showAdIfAvailable(it) }
    }

    // -------------------------------------------------------------------------------------------
    // Load / Show
    // -------------------------------------------------------------------------------------------

    private fun loadAd() {
        if (isLoadingAd || isAdAvailable()) return
        isLoadingAd = true

        AppOpenAd.load(
            application,
            application.getString(R.string.ad_app_open_id),
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    log("AppOpenAd loaded")
                    appOpenAd = ad
                    isLoadingAd = false
                    loadTime = Date().time
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    log("AppOpenAd failed to load: ${error.message}")
                    isLoadingAd = false
                }
            }
        )
    }

    private fun showAdIfAvailable(activity: Activity) {
        if (FullScreenAdState.isShowingAd) return

        if (!isAdAvailable()) {
            loadAd()
            return
        }

        val ad = appOpenAd ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                log("AppOpenAd dismissed")
                appOpenAd = null
                FullScreenAdState.isShowingAd = false
                loadAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                log("AppOpenAd failed to show: ${adError.message}")
                appOpenAd = null
                FullScreenAdState.isShowingAd = false
                loadAd()
            }

            override fun onAdShowedFullScreenContent() {
                log("AppOpenAd shown")
                FullScreenAdState.isShowingAd = true
            }
        }
        ad.show(activity)
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanHoursAgo(AD_EXPIRY_HOURS)
    }

    private fun wasLoadTimeLessThanHoursAgo(hours: Long): Boolean {
        val dateDifference = Date().time - loadTime
        val msPerHour = 3_600_000L
        return dateDifference < msPerHour * hours
    }

    // -------------------------------------------------------------------------------------------
    // ActivityLifecycleCallbacks — відстежуємо поточну Activity
    // -------------------------------------------------------------------------------------------

    override fun onActivityStarted(activity: Activity) {
        // Не оновлюємо, поки показується реклама (там теж Activity)
        if (!FullScreenAdState.isShowingAd) currentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity === activity) currentActivity = null
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityResumed(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
}